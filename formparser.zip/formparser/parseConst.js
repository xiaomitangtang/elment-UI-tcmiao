export const IsNull = 'IsNull'
export const IsNotNull = 'IsNotNull'
export const GreaterAndEqual = 'GreaterAndEqual'
export const Disabled = 'Hide'
